package com.example.demo.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.bean.RegisterDTO;

public interface JPARepository extends JpaRepository<RegisterDTO, String> {
	public RegisterDTO getByEmail(String s);
	public RegisterDTO deleteByEmail(String s);
}
