package com.example.register.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Component;
import com.example.register.DTO.StudentDTO;

@Component
public interface RepositoryMysql extends JpaRepository<StudentDTO, String>{

	
}
