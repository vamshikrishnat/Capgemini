package com.example.register.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.register.DTO.StudentDTO;
import com.example.register.repo.RepositoryMysql;

@Controller
@EnableJpaRepositories(basePackageClasses = RepositoryMysql.class)
public class RegisterController {

	@Autowired
	RepositoryMysql mysql;
	
	@GetMapping()
	public String registerPage()
	{
		return "Register";
	}
	
	@PostMapping()
	public String register(@ModelAttribute StudentDTO dto)
	{
		mysql.save(dto);
		return "Success";
	}
}
